import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextPane;
import javax.swing.JList;

public class ResponsabileDiCassaGUI {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args, ResponsabileDiCassa Jasmin) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ResponsabileDiCassaGUI window = new ResponsabileDiCassaGUI(Jasmin);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ResponsabileDiCassaGUI(ResponsabileDiCassa Jasmin) {
		initialize(Jasmin);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(ResponsabileDiCassa Jasmin) {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 700, 700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		ImageIcon img = new ImageIcon("ShellKrustyKrab.png");
    	frame.setIconImage(img.getImage());
    	
		JTextPane txtpnResponsabileDiCassa = new JTextPane();
		txtpnResponsabileDiCassa.setEditable(false);
		txtpnResponsabileDiCassa.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtpnResponsabileDiCassa.setText("                                 RESPONSABILE DI CASSA");
		txtpnResponsabileDiCassa.setBounds(0, 0, 694, 45);
		frame.getContentPane().add(txtpnResponsabileDiCassa);
		
		JButton btnNewButton = new JButton("Indietro");
		btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
			}
		});
		btnNewButton.setBounds(91, 548, 135, 65);
		frame.getContentPane().add(btnNewButton);
		
		
		DefaultListModel<Ordine> model = new DefaultListModel<>();
		
		System.out.println(Jasmin.getOrdiniDaPagare().size());
		for (int i = 0; i < Jasmin.getOrdiniDaPagare().size(); i++) {
			model.addElement(Jasmin.getOrdiniDaPagare().get(i));
			
		}
		
		JList<Ordine> list = new JList<>(model);
		list.setBounds(77, 81, 544, 353);
		frame.getContentPane().add(list);
		
		JButton btnNewButton_1 = new JButton("Genera Scontrino");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					int index = list.getSelectedIndex();
					if (Jasmin.getOrdiniDaPagare().get(index).getPiattiOrdinati().size() == 0) {					
						model.removeElement(Jasmin.getOrdiniDaPagare().get(index));
						Jasmin.creaScontrino(Jasmin.getOrdiniDaPagare().get(index));
						//System.out.println(index);
						//Jasmin.removeOrdinePagato(index);
					}
					else {
						ErrorGUI2.main(null);
					}
				}
				catch (Exception ex) {
					
				}
			}
		});
		btnNewButton_1.setBounds(474, 548, 135, 65);
		frame.getContentPane().add(btnNewButton_1);
		
	}
}
